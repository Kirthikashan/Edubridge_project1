public class Student {
    private int id;
    private String name;
    private int grade;
    private int feesPaid;
    private int feesTotal;

    public Student(int id, String name, int grade) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.feesPaid = 0;
        this.feesTotal = 30000; // Setting total fees for each student
    }

    public void payFees(int fees) {
        this.feesPaid += fees;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getGrade() {
        return grade;
    }

    public int getFeesPaid() {
        return feesPaid;
    }

    public int getFeesRemaining() {
        return feesTotal - feesPaid;
    }

    public String toString() {
        return name + " (Grade " + grade + ") paid fees: $" + feesPaid;
    }
}
